<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_STAFF_EDIT_NO_MODULE'] = 'Модуль "Litebox" не установлен.';
$MESS['LITEBOX_Z1_STAFF_EDIT_NOT_FOUND'] = 'Сотрудник не существует.';
$MESS['LITEBOX_Z1_STAFF_EDIT_TITLE_DEFAULT'] = 'Сотрудник';
$MESS['LITEBOX_Z1_STAFF_EDIT_SHOW_TITLE'] = 'Сотрудник №#ID# &mdash; #FIO#';
$MESS['LITEBOX_Z1_STAFF_EDIT_ERROR_EMPTY_FIO'] = 'Значение не задано.';
$MESS['LITEBOX_Z1_STAFF_EDIT_ERROR_EMPTY_POSITION_ID'] = 'Не указана должность';
$MESS['LITEBOX_Z1_STAFF_EDIT_ERROR_UNKNOWN_POSITION_ID'] = 'Указанная должность не существует';