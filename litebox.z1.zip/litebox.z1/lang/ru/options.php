<?php
/**
 * Синицын АВ - 2020
 */

$MESS["LITEBOX_TEST_TAB_SETTINGS"] = "Основные настройки";
$MESS["LITEBOX_TEST_FIELD_TEXT_TITLE"] = "Поле типа текст";
$MESS["LITEBOX_TEST_FIELD_LINE_TITLE"] = "Поле типа строка";
$MESS["LITEBOX_TEST_FIELD_LIST_TITLE"] = "Поле типа список";
