<?
/**

 * Синицын АВ - 2020
 */
$MESS["LITEBOX_TEST_MODULE_NAME"] = "Тестовый модуль D7";
$MESS["LITEBOX_TEST_MODULE_DESC"] = "Описание модуля";
$MESS["LITEBOX_TEST_PARTNER_NAME"] = "LiteBox";
$MESS["LITEBOX_TEST_PARTNER_URI"] = "https://litebox.ru/";

$MESS["LITEBOX_TEST_INSTALL_TITLE"] = "Установка модуля";
$MESS["LITEBOX_TEST_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";

#работа с .settings.php
$MESS["LITEBOX_TEST_INSTALL_COUNT"] = "Количество установок модуля: ";
$MESS["LITEBOX_TEST_UNINSTALL_COUNT"] = "Количество удалений модуля: ";

$MESS["LITEBOX_TEST_NO_CACHE"] = 'Внимание, на сайте выключено кеширование!<br>Возможно замедление в работе модуля.';
#работа с .settings.php
?>
