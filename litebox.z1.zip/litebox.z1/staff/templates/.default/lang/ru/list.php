<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_LIST_TITLE'] ='CОТРУДНИКИ';
$MESS['LITEBOX_Z1_STAFF_LIST_TITLE_ADD'] = 'ДОБАВИТЬ СОТРУДНИКА';
$MESS['LITEBOX_Z1_STAFF_LIST_TEXT_ADD'] = 'ДОБАВИТЬ СОТРУДНИКА';
$MESS['LITEBOX_Z1_STAFF_LIST_TITLE_EXP'] = 'ЭКСПОРТ CSV';
$MESS['LITEBOX_Z1_STAFF_LIST_TEXT_EXP'] = 'ЭКСПОРТ CSV';