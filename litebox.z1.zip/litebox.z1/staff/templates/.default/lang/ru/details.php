<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_STAFF_EDIT'] = 'Редактировать';
