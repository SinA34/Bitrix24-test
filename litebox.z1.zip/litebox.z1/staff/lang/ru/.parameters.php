<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_DETAILS_URL_TEMPLATE'] = 'Шаблон пути к карточке сотрудника';
$MESS['LITEBOX_Z1_EDIT_URL_TEMPLATE'] = 'Шаблон пути к форме редактирования карточки сотрудника';