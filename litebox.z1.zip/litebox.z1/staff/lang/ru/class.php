<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_SEF_NOT_ENABLED'] = 'Режим ЧПУ должен быть включен.';
$MESS['LITEBOX_Z1_SEF_BASE_EMPTY'] = 'Не указан каталог ЧПУ.';
