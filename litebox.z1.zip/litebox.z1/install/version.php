<?php

/**
 * Синицын АВ - 2020
 */
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2020-10-14 17:00:00"
);
?>
