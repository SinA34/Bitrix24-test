<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['CRMSTORES_NO_MODULE'] = 'Модуль "Торговые точки CRM" не установлен.';
$MESS['CRMSTORES_STORE_NOT_FOUND'] = 'Торговая точка не существует.';
$MESS['CRMSTORES_SHOW_TITLE_DEFAULT'] = 'Торговая точка';
$MESS['CRMSTORES_SHOW_TITLE'] = 'Торговая точка №#ID# &mdash; #NAME#';
$MESS['CRMSTORES_ERROR_EMPTY_NAME'] = 'Название торговой точки не задано.';
$MESS['CRMSTORES_ERROR_EMPTY_ASSIGNED_BY_ID'] = 'Не указан ответственный.';
$MESS['CRMSTORES_ERROR_UNKNOWN_ASSIGNED_BY_ID'] = 'Указанный ответственный сотрудник не существует.';