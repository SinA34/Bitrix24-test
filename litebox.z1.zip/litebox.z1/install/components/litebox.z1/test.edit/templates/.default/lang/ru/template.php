<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['CRMSTORES_NO_CRM_MODULE'] = 'Модуль CRM не установлен.';
$MESS['CRMSTORES_TAB_STORE_NAME'] = 'Торговая точка';
$MESS['CRMSTORES_TAB_STORE_TITLE'] = 'Свойства торговой точки';
$MESS['CRMSTORES_FIELD_SECTION_STORE'] = 'Торговая точка';
$MESS['CRMSTORES_FIELD_ID'] = 'ID';
$MESS['CRMSTORES_FIELD_NAME'] = 'Название';
$MESS['CRMSTORES_FIELD_ADDRESS'] = 'Адрес';
$MESS['CRMSTORES_FIELD_ASSIGNED_BY'] = 'Ответственный';
$MESS['CRMSTORES_TAB_DEALS_NAME'] = 'Сделки';
$MESS['CRMSTORES_TAB_DEALS_TITLE'] = 'Связанные сделки';