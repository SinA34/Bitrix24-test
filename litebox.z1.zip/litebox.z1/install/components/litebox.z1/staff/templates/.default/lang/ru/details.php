<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['CRMSTORES_EDIT'] = 'Редактировать';
