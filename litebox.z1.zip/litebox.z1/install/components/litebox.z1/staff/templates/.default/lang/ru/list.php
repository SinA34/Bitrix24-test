<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['CRMSTORES_LIST_TITLE'] = 'Торговые точки';
$MESS['CRMSTORES_ADD'] = 'Добавить';