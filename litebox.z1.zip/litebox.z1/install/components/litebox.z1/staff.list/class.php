<?php
defined('B_PROLOG_INCLUDED') || die;

use Litebox\Z1;
use Bitrix\Main\Context;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\UI\PageNavigation;
use Bitrix\Main\Grid;
use Bitrix\Main\UI\Filter;
use Bitrix\Main\Web\Json;
use Bitrix\Main\Web\Uri;


class LiteboxStaffListComponent extends CBitrixComponent
{
    const GRID_ID = 'LITEBOXTEST_STEFF_LIST';
    const SORTABLE_FIELDS = array('ID', 'FIO', 'POSITION');
    const FILTERABLE_FIELDS = array('ID', 'FIO', 'POSITION');
    const SUPPORTED_ACTIONS = array('delete');
    const SUPPORTED_SERVICE_ACTIONS = array('GET_ROW_COUNT');

    private static $headers;
    private static $filterFields;
    private static $filterPresets;

    public function __construct(CBitrixComponent $component = null)
    {
        global $USER;

        parent::__construct($component);

        self::$headers = array(
            array(
                'id' => 'ID',
                'name' => Loc::getMessage('LITEBOXTEST_STEFF_ID'),
                'sort' => 'ID',
                'first_order' => 'desc',
                'type' => 'int',
            ),
            array(
                'id' => 'FIO',
                'name' => Loc::getMessage('LITEBOXTEST_STEFF_FIO'),
                'sort' => 'FIO',
                'default' => true,
            ),
            array(
                'id' => 'POSITION',
                'name' => Loc::getMessage('LITEBOXTEST_STEFF_POSITION'),
                'sort' => 'POSITION',
                'default' => true,
            ),
        );

        self::$filterFields = array(
            array(
                'id' => 'ID',
                'name' => Loc::getMessage('LITEBOXTEST_STEFF_FILTER_FIELD_ID')
            ),
            array(
                'id' => 'FIO',
                'name' => Loc::getMessage('LITEBOXTEST_STEFF_FILTER_FIELD_FIO'),
                'default' => true,
            ),
            array(
                'id' => 'POSITION',
                'name' => Loc::getMessage('LITEBOXTEST_STEFF_FIELD_POSITION'),
                'default' => true,
            ),
        );
    }

    public function executeComponent()
    {
        if (!Loader::includeModule('litebox.z1')) {
            ShowError(Loc::getMessage('LITEBOXTEST_STEFF_NO_MODULE'));
            return;
        }

        $context = Context::getCurrent();
        $request = $context->getRequest();

        $grid = new Grid\Options(self::GRID_ID);

        //region Sort
        $gridSort = $grid->getSorting();
        $sort = array_filter(
            $gridSort['sort'],
            function ($field) {
                return in_array($field, self::SORTABLE_FIELDS);
            },
            ARRAY_FILTER_USE_KEY
        );
        if (empty($sort)) {
            $sort = array('FIO' => 'asc');
        }

        // Filter
        $gridFilter = new Filter\Options(self::GRID_ID, self::$filterPresets);
        $gridFilterValues = $gridFilter->getFilter(self::$filterFields);
        $gridFilterValues = array_filter(
            $gridFilterValues,
            function ($fieldName) {
                return in_array($fieldName, self::FILTERABLE_FIELDS);
            },
            ARRAY_FILTER_USE_KEY
        );
        // /Filter

        $this->processGridActions($gridFilterValues);
        $this->processServiceActions($gridFilterValues);

        // Pagination
        $gridNav = $grid->GetNavParams();
        $pager = new PageNavigation('');
        $pager->setPageSize($gridNav['nPageSize']);
        $pager->setRecordCount(StoreTable::getCount($gridFilterValues));
        if ($request->offsetExists('page')) {
            $currentPage = $request->get('page');
            $pager->setCurrentPage($currentPage > 0 ? $currentPage : $pager->getPageCount());
        } else {
            $pager->setCurrentPage(1);
        }
        // /Pagination

        $staff = $this->getStaff(array(
            'filter' => $gridFilterValues,
            'limit' => $pager->getLimit(),
            'offset' => $pager->getOffset(),
            'order' => $sort
        ));

        $requestUri = new Uri($request->getRequestedPage());
        $requestUri->addParams(array('sessid' => bitrix_sessid()));

        $this->arResult = array(
            'GRID_ID' => self::GRID_ID,
            'STAFF' => $staff,
            'HEADERS' => self::$headers,
            'PAGINATION' => array(
                'PAGE_NUM' => $pager->getCurrentPage(),
                'ENABLE_NEXT_PAGE' => $pager->getCurrentPage() < $pager->getPageCount(),
                'URL' => $request->getRequestedPage(),
            ),
            'SORT' => $sort,
            'FILTER' => self::$filterFields,
            'FILTER_PRESETS' => self::$filterPresets,
            'ENABLE_LIVE_SEARCH' => false,
            'DISABLE_SEARCH' => true,
            'SERVICE_URL' => $requestUri->getUri(),
        );

        $this->includeComponentTemplate();
    }

    private function getStaff($params = array())
    {
        $db = Z1\StaffTable::getList($params);
        return $db->fetchAll();
    }

    private function processGridActions($currentFilter)
    {
        if (!check_bitrix_sessid()) {
            return;
        }

        $context = Context::getCurrent();
        $request = $context->getRequest();

        $action = $request->get('action_button_' . self::GRID_ID);

        if (!in_array($action, self::SUPPORTED_ACTIONS)) {
            return;
        }

        $allRows = $request->get('action_all_rows_' . self::GRID_ID) == 'Y';
        if ($allRows) {
            $db = StaffTable::getList(array(
                'filter' => $currentFilter,
                'select' => array('ID'),
            ));
            $staffIds = array();
            foreach ($db as $staff) {
                $staffIds[] = $staff['ID'];
            }
        } else {
            $staffIds = $request->get('ID');
            if (!is_array($staffIds)) {
                $staffIds = array();
            }
        }

        if (empty($staffIds)) {
            return;
        }

        switch ($action) {
            case 'delete':
                foreach ($staffIds as $staffId) {
                    Z1\StaffTable::delete($staffId);
                }
            break;

            default:
            break;
        }
    }

    private function processServiceActions($currentFilter)
    {
        global $APPLICATION;

        if (!check_bitrix_sessid()) {
            return;
        }

        $context = Context::getCurrent();
        $request = $context->getRequest();

        $params = $request->get('PARAMS');

        if (empty($params['GRID_ID']) || $params['GRID_ID'] != self::GRID_ID) {
            return;
        }

        $action = $request->get('ACTION');

        if (!in_array($action, self::SUPPORTED_SERVICE_ACTIONS)) {
            return;
        }

        $APPLICATION->RestartBuffer();
        header('Content-Type: application/json');

        switch ($action) {
            case 'GET_ROW_COUNT':
                $count = StoreTable::getCount($currentFilter);
                echo Json::encode(array(
                    'DATA' => array(
                        'TEXT' => Loc::getMessage('LITEBOXTEST_GRID_ROW_COUNT', array('#COUNT#' => $count))
                    )
                ));
            break;

            default:
            break;
        }

        die;
    }
}
