<?
/**
 * Синицын АВ - 2020
 */
$MESS["LITEBOX_TEST_MODULE_NOT_INSTALLED"] = "Модуль  LiteBox тест не установлен!";
