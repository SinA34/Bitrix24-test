<?php
/**
 * Синицын АВ - 2020
 */
use \Bitrix\Main\Loader;
use \Bitrix\Main\Localization\Loc;

class TestClass extends CBitrixComponent
{
    var $test;

    protected function checkModules()
    {
        if (!Loader::includeModule('litebox.test'))
        {
            ShowError(Loc::getMessage('LITEBOX_TEST_MODULE_NOT_INSTALLED'));
            return false;
        }

        return true;
    }

    public function executeComponent()
    {
        $this -> includeComponentLang('class.php');

        if($this -> checkModules())
        {
            /*Ваш код*/

            $this->includeComponentTemplate();
        }
    }
};
