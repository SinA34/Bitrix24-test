<?php
/**
 * Синицын АВ - 2020
 *
 * файл default_option.php
 */
