<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_STAFF_LIST_TITLE_PAGE'] = 'СОТРУДНИКИ';
$MESS['LITEBOX_Z1_STAFF_LIST_GRID_ROW_EDIT'] = 'Редактировать';
$MESS['LITEBOX_Z1_STAFF_LIST_GRID_ROW_ADD'] = 'Добавить запись';

