<?php
defined('B_PROLOG_INCLUDED') || die;


$MESS['LITEBOX_Z1_STAFF_NOT_FOUND'] = 'Таблицы Сотрудники не сущестует';
$MESS['LITEBOX_Z1_STAFF_EXP_TITLE_DEFAULT'] = 'Сотрудник экспорт';
$MESS['LITEBOX_Z1_NOT_FOUND'] = 'Модуль Litebox не подключен';
