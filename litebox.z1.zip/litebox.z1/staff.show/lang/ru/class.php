<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['LITEBOX_Z1_NO_MODULE'] = 'Модуль "Litebox" не установлен.';
$MESS['LITEBOX_Z1_STAFF_SHOW_NOT_FOUND'] = 'Сотрудник не существует.';
$MESS['LITEBOX_Z1_STAFF_SHOW_TITLE_DEFAULT'] = 'Сотрудник';
$MESS['LITEBOX_Z1_STAFF_SHOW_TITLE'] = 'Сотрудник №#ID# &mdash; #FIO#';
